#Simple Hello World program
print("Hello world")