Please note that the following files:
	HelloWorld.Clean.ipynb
	NumPy.Clean.ipynb
	Pandas and MathPlotLib.Clean.ipynb
	PythonCrashCourse.Clean.ipynb
	SciKitLearn.Clean.ipynb
	SciPy.Clean.ipynb
	Titanic.Clean.ipynb
Haven't been run so you can run the code blocks for yourself.

If you want to see the output right away, please view:
	HelloWorld.with-Output.ipynb
	NumPy.with-Output.ipynb
	Pandas and MathPlotLib.with-Output.ipynb
	PythonCrashCourse.with-Output.ipynb
	SciPy.with-Output.ipynb
	Titanic.with-Output.ipynb
You can run the code form there.

The Sample Notebooks are from:
http://www.tbdatascientist.com/live1.html

Enjoy!